Oppgaven fungerer som den skal, alts� den sorterer de 40 st�rste tallene inn i en array. 
Har ogs� med tidtagning, men syns at den sekvensielle alogritmen tar litt kort tid, men ikke funnet ut av hva dette skyldes.
Har stortsett kj�rt testene p� en laptop med liten prossessor, kun testet gjennomkj�ringen p� en stasjon�r pc et par ganger.

-Emil
emilstro